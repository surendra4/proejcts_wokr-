import streamlit as st
import streamlit.components.v1 as components
from PIL import Image
# st.markdown("<h1 style='text-align:center;color:black;background-color:brown'>BITCOIN PRICE PREDICTION MODEL</h1>",unsafe_allow_html=True)
# st.markdown("<p>A Meaningful Page Title</p>",unsafe_allow_html=True)
st.set_page_config(page_title="Capstone Project Based on ML",page_icon='https://img.icons8.com/external-wanicon-lineal-color-wanicon/2x/external-machine-learning-smart-industry-wanicon-lineal-color-wanicon.png')
st.markdown("<h1 style='width:1800;text-align:center;color:orange;background-color:steelblue;width:1500'>BANK CUSTOMERS DATA ANALYSIS</h1>",unsafe_allow_html=True)
st.write('\n')
st.markdown("<p>Note: Click &nbsp; &#8801; &nbsp; on top right corner and check in &#10003; the wide mode for enhanced view</p>",unsafe_allow_html=True)
print("Hello ML World")
import streamlit as st
import pandas as pd
st.title("Customer Analysis Report")
html_temp = """<div class='tableauPlaceholder' id='viz1643282230725' style='position: relative'><object class='tableauViz'  style='display:none;'><param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F' /> <param name='embed_code_version' value='3' /> <param name='site_root' value='' /><param name='name' value='CAPSTONEREPORTVIZ&#47;Story1' /><param name='tabs' value='no' /><param name='toolbar' value='yes' /><param name='animate_transition' value='yes' /><param name='display_static_image' value='yes' /><param name='display_spinner' value='yes' /><param name='display_overlay' value='yes' /><param name='display_count' value='yes' /><param name='language' value='en-US' /><param name='filter' value='publish=yes' /></object></div>                <script type='text/javascript'>                    var divElement = document.getElementById('viz1643282230725');                    var vizElement = divElement.getElementsByTagName('object')[0];                    vizElement.style.width='1116px';vizElement.style.height='991px';                    var scriptElement = document.createElement('script');                    scriptElement.src = 'https://public.tableau.com/javascripts/api/viz_v1.js';                    vizElement.parentNode.insertBefore(scriptElement, vizElement);                </script>"""
components.html(html_temp,width=1500,height=1550)





