use capstone_project;
select * from account;
select * from card;
select * from client;
select * from disp;
select * from district;
select * from loan;
select * from order_;
select * from transaction_data;


-- join loan and transation table with account_id
CREATE TABLE loan_tran    #1670 row
select td.*,ln.loan_id,ln.date as loan_date,ln.amount as loan_amount,ln.duration,ln.payments,
ln.status as loan_status from loan ln join transaction_data td on
ln.account_id =td.account_id; 

-- account 0rder table with account_id (inner join)
create table acc_ord   #7213 rows
select o.*,acc.date as account_date,acc.district_id as account_district_id,
acc.frequency as acc_frequency from account acc left join order_ o on acc.account_id = o.account_id;
select count(*) from acc_ord;

-- card and disosition order table (inner table ).
create table card_disp  #892 rows
select c.*,disp.account_id ,disp.client_id as disp_client_id,
disp.type as disp_type from card c join disp disp on c.disp_id = disp.disp_id;
select * from card_disp;

-- card and disposition combine with Client table based on client_id(inner join) 
create table card_disp_client    #892 rows
select * from card_disp cd join client c on cd.disp_client_id = c.client_id;

-- card, Dispositon,client table with district Table based on district id(inner join) #624ROWS
create table card_disp_client_dist  #892
select * from card_disp_client cdc join district d on cdc.district_id = d.A1;
select * from  card_disp_client_dist;

-- #account,order table with card,disposition,client,district table based on account id(left join)
CREATE table acc_ord_card_disp_client_dist     #7213 rows
select cdcd.*,ao.order_id,ao.bank_to,ao.account_to,ao.amount,ao.k_symbol,ao.account_date,
ao.account_district_id,ao.acc_frequency as frequency from acc_ord ao left join card_disp_client_dist cdcd on ao.account_id = cdcd.account_id;

select * from acc_ord_card_disp_client_dist;

#join account,order,card,disposition,client,district with loan,transaction table based on account_id(inner join)
 #868
SELECT * FROM
    acc_ord_card_disp_client_dist aocdcd
        JOIN
    loan_tran lt ON lt.account_id = aocdcd.account_id order by card_id asc;